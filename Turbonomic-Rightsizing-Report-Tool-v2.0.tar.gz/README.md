# Turbonomic Rightsizing Report Generator

**Professional tool for generating comprehensive VM rightsizing recommendations from IBM Turbonomic**

## Overview

This tool extracts rightsizing recommendations from Turbonomic and generates detailed Excel reports with cost analysis, environment filtering, and customizable customer mapping. Perfect for presenting optimization opportunities to stakeholders and tracking cost savings initiatives.

## Key Features

✅ **Comprehensive Reporting** - Extract all VM rightsizing recommendations with detailed metrics
✅ **Environment Filtering** - Separate reports by Dev, UAT, Pre-Prod, Prod, and DR environments
✅ **Cost Analysis** - Calculate monthly savings (downsizing) and net add costs (upsizing)
✅ **Customer Mapping** - Map technical VMs to business-friendly customer names
✅ **Multiple Versions** - Choose from v1 (basic), v2 (enhanced), or v3 (advanced) based on needs
✅ **Disk Optimization** - Additional tool for storage rightsizing recommendations
✅ **Monthly Action Plan** - NEW! Categorized action plan for maintenance window execution
✅ **Excel Export** - Professional formatted reports ready for stakeholder review

## What's Included

```
turbonomic-rightsizing-report-delivery/
├── README.md                                    # This file
├── INSTALLATION.md                              # Detailed setup instructions
├── QUICKSTART.md                                # Get started in 5 minutes
├── MONTHLY_ACTION_PLAN.md                       # Monthly Action Plan guide
├── CUSTOMER_MAPPING.md                          # Customer mapping configuration
├── requirements.txt                             # Python dependencies
├── generate_rightsizing_report.py               # Main report generator (v1)
├── generate_rightsizing_report_v2.py            # Enhanced version with better filtering
├── generate_rightsizing_report_v3.py            # Advanced version with customer mapping
├── generate_disk_optimization_report.py         # Disk/storage optimization reports
├── generate_monthly_action_plan.py              # NEW! Monthly action plan generator
├── generate_all_environment_reports.sh          # Batch script for all environments
├── customer_mapping.json.example                # Customer mapping template
└── LICENSE                                      # Apache 2.0 License
```

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Get Turbonomic Session ID

```bash
curl -X POST 'https://your-turbo-instance.com/api/v3/login' \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d 'username=your-username&password=your-password' \
     -c cookies.txt

# Extract session ID
grep JSESSIONID cookies.txt | awk '{print $7}'
```

### 3. Generate Your First Report

```bash
# Basic report (all environments)
python generate_rightsizing_report.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --output rightsizing_report.xlsx

# Production environment only
python generate_rightsizing_report.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --environment Prod \
    --output prod_rightsizing.xlsx
```

## Report Output

Each report includes:

| Column | Description |
|--------|-------------|
| **Server Name** | VM identifier |
| **Customer Friendly Name** | Business/application name (from mapping) |
| **Current Configuration** | Current VM size (e.g., m5.large, 4 vCPU/16GB RAM) |
| **Recommendation** | Suggested VM size or configuration |
| **Action Type** | Downsize, Upsize, or Resize |
| **Monthly Savings** | Estimated cost reduction (downsizing) |
| **Net Add Cost** | Additional monthly cost (upsizing in Prod) |
| **Environment** | Dev, UAT, Pre-Prod, Prod, or DR |
| **Action State** | READY, QUEUED, IN_PROGRESS, etc. |
| **Risk** | Risk severity level |
| **UUID** | Unique entity identifier |

## Version Comparison

| Feature | v1 (Basic) | v2 (Enhanced) | v3 (Advanced) |
|---------|------------|---------------|---------------|
| Basic rightsizing data | ✅ | ✅ | ✅ |
| Environment filtering | ✅ | ✅ | ✅ |
| Cost calculations | ✅ | ✅ | ✅ |
| Excel formatting | ✅ | ✅ | ✅ |
| Enhanced filtering | ❌ | ✅ | ✅ |
| Customer mapping | ❌ | ❌ | ✅ |
| Summary reports | ❌ | ❌ | ✅ |

**Recommendation**: Start with v1 for basic needs, use v3 for customer-facing reports.

## Common Use Cases

### Generate Reports for All Environments

```bash
# Make script executable
chmod +x generate_all_environment_reports.sh

# Run batch generation
./generate_all_environment_reports.sh YOUR_SESSION_ID
```
### Monthly Action Plan (NEW!)

Generate a comprehensive monthly maintenance action plan with categorized actions:

```bash
python generate_monthly_action_plan.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --output Monthly_Action_Plan.xlsx
```

This creates a report with three categories:
1. **Must-Do Actions** - Policy violations + validated downsizing
2. **Cost Optimization** - Recommended downsizing across all environments  
3. **Reliability Investment** - Prod upsizing with budget impact

See [MONTHLY_ACTION_PLAN.md](MONTHLY_ACTION_PLAN.md) for complete documentation.


This creates separate reports for:
- Dev environment
- UAT environment  
- Pre-Prod environment
- Production environment
- DR environment
- Comprehensive (all environments combined)

### Production Downsizing Opportunities

```bash
python generate_rightsizing_report.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --environment Prod \
    --action-type downsize \
    --output prod_cost_savings.xlsx
```

### Customer-Mapped Reports (v3)

```bash
# First, configure customer mapping
cp customer_mapping.json.example customer_mapping.json
# Edit customer_mapping.json with your mappings

# Generate report with friendly names
python generate_rightsizing_report_v3.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --output customer_report.xlsx
```

### Disk Optimization Reports

```bash
python generate_disk_optimization_report.py \
    --url https://your-turbo-instance.com \
    --jsessionid YOUR_SESSION_ID \
    --output disk_optimization.xlsx
```

## Customer Mapping

Map technical VM names to business-friendly customer names for stakeholder reports:

```json
{
  "vm-prod-app-01": "Customer Portal Application",
  "vm-prod-db-01": "Customer Database Server",
  "vm-dev-.*": "Development Environment"
}
```

See [`customer_mapping.json.example`](customer_mapping.json.example) for complete examples.

## Documentation

- **[INSTALLATION.md](INSTALLATION.md)** - Detailed installation and setup guide
- **[QUICKSTART.md](QUICKSTART.md)** - Get started in 5 minutes
- **[CUSTOMER_MAPPING.md](CUSTOMER_MAPPING.md)** - Customer mapping configuration guide

## System Requirements

- **Python**: 3.6 or higher
- **Operating System**: Windows, macOS, or Linux
- **Network**: Access to Turbonomic instance
- **Permissions**: Turbonomic user with read access to actions and entities

## Troubleshooting

### "Error: 401 Unauthorized"
Your session expired. Get a new JSESSIONID (see step 2 above).

### "pandas not installed"
Install required dependencies:
```bash
pip install pandas openpyxl
```

### "No data in report"
- Verify there are pending recommendations in Turbonomic
- Check environment filter isn't too restrictive
- Ensure VMs have proper tags (Environment, CustomerID)

### Session ID expires quickly
Turbonomic sessions typically last 30 minutes. For automated reports, consider:
- Running reports immediately after authentication
- Implementing automatic re-authentication in your workflow

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the detailed documentation files
3. Verify Turbonomic credentials and permissions
4. Ensure VMs have required tags configured

## License

Copyright IBM. All Rights Reserved.

SPDX-License-Identifier: Apache-2.0

This tool is provided as-is for use with IBM Turbonomic. See LICENSE file for details.

## Version

**Release**: 1.0  
**Date**: April 2026  
**Compatibility**: Turbonomic 8.x API v3

---

**Ready to get started?** See [QUICKSTART.md](QUICKSTART.md) for a 5-minute setup guide.