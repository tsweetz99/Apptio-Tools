#!/usr/bin/env python3
"""
Debug script to examine disk action data structure
"""

import requests
import json
import argparse
import sys

def debug_disk_actions(turbo_url: str, jsessionid: str):
    """Fetch and display structure of disk actions."""
    url = f"{turbo_url.rstrip('/')}/api/v3/markets/Market/actions"
    
    session = requests.Session()
    session.cookies.set('JSESSIONID', jsessionid)
    session.headers.update({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    })
    
    payload = {
        "actionStateList": ["READY", "ACCEPTED", "QUEUED", "IN_PROGRESS"],
        "actionTypeList": ["RESIZE", "SCALE", "RECONFIGURE"],
        "relatedEntityTypes": ["VirtualVolume", "Storage", "Volume", "VirtualMachineVolume"],
        "environmentType": "CLOUD",
        "detailLevel": "EXECUTION"
    }
    
    params = {
        "ascending": "false",
        "cursor": "0",
        "disable_hateoas": "true",
        "forceExpansionOfAggregatedEntities": "true",
        "order_by": "savings",
        "limit": "5"  # Just get first 5 for debugging
    }
    
    try:
        print(f"Fetching disk actions from {url}...")
        response = session.post(url, json=payload, params=params)
        response.raise_for_status()
        
        actions = response.json()
        
        if not actions:
            print("No disk actions found")
            return
        
        print(f"\nFound {len(actions)} disk actions. Examining first action:\n")
        print("="*80)
        
        action = actions[0]
        
        # Print full action structure
        print("FULL ACTION STRUCTURE:")
        print(json.dumps(action, indent=2))
        print("\n" + "="*80)
        
        # Print specific fields we're interested in
        print("\nKEY FIELDS:")
        print(f"Action UUID: {action.get('uuid', 'N/A')}")
        print(f"Action Type: {action.get('actionType', 'N/A')}")
        print(f"Details: {action.get('details', 'N/A')}")
        
        target = action.get('target', {})
        print(f"\nTarget Display Name: {target.get('displayName', 'N/A')}")
        print(f"Target UUID: {target.get('uuid', 'N/A')}")
        print(f"Target Class: {target.get('className', 'N/A')}")
        
        print("\nProviders:")
        providers = target.get('providers', [])
        if providers:
            for i, provider in enumerate(providers):
                print(f"  Provider {i}: {json.dumps(provider, indent=4)}")
        else:
            print("  None")
        
        print("\nConsumers:")
        consumers = target.get('consumers', [])
        if consumers:
            for i, consumer in enumerate(consumers):
                print(f"  Consumer {i}: {json.dumps(consumer, indent=4)}")
        else:
            print("  None")
        
        print("\nAspects:")
        aspects = target.get('aspects', {})
        if aspects:
            print(json.dumps(aspects, indent=2))
        else:
            print("  None")
        
        print("\n" + "="*80)
        print("\nSave this output and share it to identify where VM name is stored.")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

def main():
    parser = argparse.ArgumentParser(description='Debug disk action structure')
    parser.add_argument('--url', required=True, help='Turbonomic instance URL')
    parser.add_argument('--jsessionid', required=True, help='Session ID')
    
    args = parser.parse_args()
    
    debug_disk_actions(args.url, args.jsessionid)

if __name__ == '__main__':
    main()

# Made with Bob
