# Consolidated Reports Guide (v4)

## Overview

Version 4 of the Turbonomic reporting tools introduces **consolidated Excel workbooks** with professional formatting, improved navigation, and corrected action links. Instead of generating separate files for each environment, you now get a single Excel file with multiple sheets.

## What's New in v4

### 1. **Single Excel Workbook Format**
- All reports consolidated into one file with multiple sheets
- Easy navigation between environments
- Consistent formatting across all sheets
- Professional color-coded styling

### 2. **Improved Sheet Structure**
Each report contains:
- **Summary Sheet**: High-level statistics and environment breakdown
- **Comprehensive Sheet**: All actions across all environments
- **Environment-Specific Sheets**: Dev, UAT, Pre-Prod, Prod, DR, Unmapped

### 3. **Corrected Action Links**
- Links now point to entity pages with actions tab pre-selected
- Format: `/app/#/view/main/live/{entity_uuid}/overview?selectedTab=actions`
- Clickable hyperlinks in Excel for easy navigation to Turbonomic UI

### 4. **Professional Formatting**
- Color-coded headers (dark blue)
- Section highlighting (light blue for categories)
- Policy violation highlighting (red background)
- Consistent borders and alignment
- Frozen header rows for easy scrolling

## Available Reports

### 1. VM Rightsizing Report (v4)
**Script**: `generate_rightsizing_report_v4.py`

**Output**: Single Excel workbook with:
- Summary sheet with overall and per-environment statistics
- Comprehensive sheet with all VM rightsizing recommendations
- Separate sheets for each environment (Dev, UAT, Pre-Prod, Prod, DR, Unmapped)

**Key Features**:
- Upsize vs. Downsize categorization based on cost impact
- Monthly savings and additional cost calculations
- Environment-based sorting (Dev → UAT → Pre-Prod → Prod → DR)
- Clickable action links to Turbonomic UI

**Usage**:
```bash
# Basic usage
python3 generate_rightsizing_report_v4.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --output-dir reports/

# With customer mapping
python3 generate_rightsizing_report_v4.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --customer-mapping customer_mapping.json \
  --output-dir reports/

# Custom output filename
python3 generate_rightsizing_report_v4.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --output rightsizing_january_2026.xlsx
```

### 2. Disk Optimization Report (v2)
**Script**: `generate_disk_optimization_report_v2.py`

**Output**: Single Excel workbook with:
- Summary sheet with policy violations and review requirements
- Comprehensive sheet with all disk tier optimizations
- Separate sheets for each environment

**Key Features**:
- Policy enforcement highlighting (Premium SSD in DEV/UAT = violation)
- Review requirements for production environments
- Monthly savings calculations
- Attached VM information
- Clickable action links

**Usage**:
```bash
# Basic usage
python3 generate_disk_optimization_report_v2.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --output-dir reports/

# With customer mapping
python3 generate_disk_optimization_report_v2.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --customer-mapping customer_mapping.json \
  --output-dir reports/

# Custom output filename
python3 generate_disk_optimization_report_v2.py \
  --url https://your-turbo-instance.com \
  --jsessionid YOUR_SESSION_ID \
  --output disk_optimization_january_2026.xlsx
```

## Report Structure Details

### Summary Sheet

The Summary sheet provides high-level statistics:

**VM Rightsizing Report Summary**:
```
OVERALL SUMMARY
- Total Recommendations: 150
- Downsizes: 120
- Upsizes: 30
- Monthly Savings: $45,000
- Monthly Add Cost: $5,000
- Net Impact: $40,000

ENVIRONMENT BREAKDOWN
- Dev: 40 actions, $12,000 savings
- UAT: 30 actions, $8,000 savings
- Pre-Prod: 20 actions, $6,000 savings
- Prod: 50 actions, $18,000 savings
- DR: 10 actions, $1,000 savings
```

**Disk Optimization Report Summary**:
```
OVERALL SUMMARY
- Total Disk Optimizations: 75
- Policy Violations: 15
- Review Required: 25
- Recommended: 35
- Monthly Savings: $8,500

ENVIRONMENT BREAKDOWN
- Dev: 20 actions (10 violations)
- UAT: 15 actions (5 violations)
- Prod: 30 actions (25 review required)
```

### Data Sheets

Each data sheet (Comprehensive and environment-specific) contains:

**VM Rightsizing Columns**:
1. Server Name
2. Customer ID
3. Customer Friendly Name
4. Current Configuration (e.g., Standard_E16s_v3)
5. Recommendation (e.g., Standard_E8s_v3)
6. Action Type (Upsize/Downsize/Resize)
7. Monthly Savings
8. Net Add Cost
9. Environment
10. Action Details Link (clickable)
11. Business Account
12. Cloud Provider
13. Action State
14. Risk
15. Details
16. UUID

**Disk Optimization Columns**:
1. Disk Name
2. Attached VM
3. Customer ID
4. Customer Friendly Name
5. Current Tier (e.g., Premium SSD)
6. Recommended Tier (e.g., Standard SSD)
7. Monthly Savings
8. Environment
9. Policy Status (POLICY VIOLATION/REVIEW REQUIRED/RECOMMENDED)
10. Justification
11. Action Details Link (clickable)
12. Business Account
13. Cloud Provider
14. Action State
15. Risk
16. UUID

## Formatting Features

### Color Coding

**Headers**: Dark blue background (#366092) with white text
**Section Headers**: Light blue background (#D9E1F2)
**Environment Rows**: Light gray background (#F2F2F2)
**Policy Violations**: Red background (#FFC7CE)

### Navigation Features

- **Frozen Header Rows**: Headers stay visible when scrolling
- **Clickable Links**: Action Details Link column contains hyperlinks
- **Consistent Widths**: Optimized column widths for readability
- **Wrapped Text**: Long text automatically wraps within cells

## Sorting Logic

All data is sorted by:
1. **Environment** (in order): Dev → UAT → Pre-Prod → Prod → DR → Unmapped
2. **Savings** (descending): Highest savings first within each environment

This ensures:
- Non-production environments appear first for quick wins
- Highest-impact actions are prioritized within each environment
- Consistent ordering across all reports

## Action Link Format

The corrected action link format is:
```
https://your-turbo-instance.com/app/#/view/main/live/{entity_uuid}/overview?selectedTab=actions
```

This links directly to:
- The entity's overview page in Turbonomic
- With the Actions tab pre-selected
- Showing all actions for that specific entity

## Migration from v3 to v4

### Key Differences

| Feature | v3 (Old) | v4 (New) |
|---------|----------|----------|
| Output Files | Multiple files (one per environment) | Single consolidated workbook |
| Action Links | Broken format | Corrected entity page format |
| Formatting | Basic | Professional with color coding |
| Navigation | Switch between files | Switch between sheets |
| Summary | Text file | Excel sheet with formatting |

### Migration Steps

1. **Update Scripts**: Use v4 scripts instead of v3
2. **Update Commands**: Same command-line arguments work
3. **Update Workflows**: Expect single Excel file output instead of multiple files
4. **Update Documentation**: Reference new sheet structure

### Backward Compatibility

- All command-line arguments remain the same
- Customer mapping file format unchanged
- Environment detection logic unchanged
- Only output format has changed

## Best Practices

### 1. Regular Report Generation
```bash
# Generate all reports monthly
python3 generate_rightsizing_report_v4.py --url $TURBO_URL --jsessionid $SESSION_ID --output-dir monthly_reports/
python3 generate_disk_optimization_report_v2.py --url $TURBO_URL --jsessionid $SESSION_ID --output-dir monthly_reports/
python3 generate_monthly_action_plan.py --url $TURBO_URL --jsessionid $SESSION_ID --output-dir monthly_reports/
```

### 2. Use Customer Mapping
Always use the customer mapping file for friendly names:
```bash
--customer-mapping customer_mapping.json
```

### 3. Organize by Date
Use timestamped output directories:
```bash
--output-dir reports/2026-01/
```

### 4. Review Summary First
1. Open the Excel file
2. Start with the Summary sheet
3. Identify high-impact environments
4. Navigate to specific environment sheets
5. Click action links to review in Turbonomic

### 5. Filter in Excel
Use Excel's built-in filtering:
- Filter by Environment
- Filter by Action Type
- Filter by Policy Status
- Sort by Monthly Savings

## Troubleshooting

### Issue: Links Not Clickable
**Solution**: Links should be automatically hyperlinked. If not, ensure you're using Excel or a compatible spreadsheet application.

### Issue: Formatting Not Visible
**Solution**: Ensure you're opening the file in Excel or LibreOffice Calc. Some viewers may not display formatting correctly.

### Issue: No Data in Environment Sheets
**Solution**: This is normal if no actions exist for that environment. Check the Summary sheet to see which environments have data.

### Issue: Policy Violations Not Highlighted
**Solution**: Red highlighting only appears in Disk Optimization reports for DEV/UAT Premium SSD violations. Ensure you're looking at the correct report type.

## Support

For issues or questions:
1. Check the main README.md
2. Review QUICKSTART.md for basic usage
3. Check TROUBLESHOOTING.md for common issues
4. Review this guide for v4-specific features

## Version History

- **v4.0** (2026-04): Consolidated Excel format, corrected action links, professional formatting
- **v3.0** (2026-03): Environment parsing from BusinessAccount
- **v2.0** (2026-02): Customer mapping support
- **v1.0** (2026-01): Initial release